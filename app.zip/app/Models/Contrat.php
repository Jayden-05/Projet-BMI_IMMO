<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Contrat extends Model
{
    use HasFactory;

    protected $fillable = [
        'transaction_id',
        'client_id',
        'bien_id',
        'numero_contrat',
        'type_contrat',
        'date_contrat',
        'date_debut',
        'date_fin',
        'montant_loyer',
        'caution',
        'conditions',
        'statut_contrat',
        'fichier_contrat',
    ];

    public function transaction()
    {
        return $this->belongsTo(Transaction::class);
    }

    public function client()
    {
        return $this->belongsTo(Client::class);
    }

    public function bien()
    {
        return $this->belongsTo(Bien::class);
    }
}
