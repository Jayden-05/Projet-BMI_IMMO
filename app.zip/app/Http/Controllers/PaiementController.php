<?php

namespace App\Http\Controllers;

use App\Models\Paiement;
use App\Models\Transaction;
use App\Models\Piece;
use Illuminate\Http\Request;

class PaiementController extends Controller
{
    // Afficher le formulaire de paiement
    public function create($transactionId)
    {
        $transaction = Transaction::with(['client', 'bien'])->findOrFail($transactionId);
        return view('paiements.create', compact('transaction'));
    }

    // Enregistrer le paiement
    public function store(Request $request)
    {
        $request->validate([
            'transaction_id' => 'required|exists:transactions,id',
            'montant_loyer' => 'required|numeric',
            'type_paiement' => 'required|string',
            'date_debut' => 'required|date',
            'date_fin' => 'required|date|after:date_debut',
            'moyen_paiement' => 'required|string',
            // Validation pour la pièce d'identité
            'numpiece' => 'required|string|unique:pieces,numpiece',
            'dateemission' => 'required|date|before_or_equal:today',
            'typepiece' => 'required|in:CNI,Passeport,Permis de conduire,Carte consulaire,Attestation identite',
        ], [
            'numpiece.unique' => 'Ce numéro de pièce existe déjà dans la base de données',
            'dateemission.before_or_equal' => 'La date d\'émission ne peut pas être dans le futur',
        ]);

        $transaction = Transaction::findOrFail($request->transaction_id);

        // Enregistrer la pièce d'identité
        Piece::create([
            'numpiece' => $request->numpiece,
            'dateemission' => $request->dateemission,
            'typepiece' => $request->typepiece,
            'client_id' => $transaction->client_id,
        ]);

        // Enregistrer le paiement
        Paiement::create([
            'transaction_id' => $transaction->id,
            'client_id' => $transaction->client_id,
            'bien_id' => $transaction->bien_id,
            'montant_loyer' => $request->montant_loyer,
            'type_paiement' => $request->type_paiement,
            'date_debut' => $request->date_debut,
            'date_fin' => $request->date_fin,
            'statut_paiement' => 'Payé',
            'moyen_paiement' => $request->moyen_paiement,
            'note' => $request->note,
        ]);

        return redirect()->route('paiements.index')
            ->with('success', 'Paiement enregistré avec succès! Pièce d\'identité ajoutée.');
    }

    // Liste des paiements
    public function index()
    {
        $paiements = Paiement::with(['client', 'bien', 'transaction'])
            ->orderBy('created_at', 'desc')
            ->get();
        return view('paiements.index', compact('paiements'));
    }
}
