<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AuthentificationController extends Controller
{
    //connexion a l'application
    public function authentification(){
        return view('authentification');
    }
}
