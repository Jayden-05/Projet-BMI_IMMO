<?php

namespace App\Http\Controllers;

use App\Models\Visite;
use App\Models\Client;
use App\Models\Bien;
use Illuminate\Http\Request;

class VisiteController extends Controller
{
    // 🔹 Affichage de la page visite
    public function visite()
    {
        $visites = Visite::with(['client', 'bien'])->get();
        return view('visite', compact('visites'));
    }

    // 🔹 Affichage de la page nouvelle visite
    public function nouvellevisite()
    {
        $clients = Client::select('id', 'nom_client', 'prenom_client')->get();
        $biens = Bien::select('id', 'type_bien', 'adresse_bien')->get();
        return view('nouvellevisite', compact('clients', 'biens'));
    }

    // 🔹 Ajout d'une nouvelle visite
    public function ajoutervisite(Request $request)
    {
        $validatedData = $request->validate([
            'bien_id' => 'required|exists:bien,id',
            'client_id' => 'required|exists:client,id',
            'date_visite' => 'required|date',
            'heure_visite' => 'required',
            'statut_visite' => 'required|string|max:50',
            'montant_visite' => 'required|numeric',
            'moyen_paiement' => 'required|string|max:50'
        ]);

        Visite::create($validatedData);

        return redirect()->route('visite')->with('success', 'Visite ajoutée avec succès.');
    }

    // 🔹 Enregistrement de la visite depuis la page détails du bien
    public function enregistrerDepuisDetails(Request $request, $bien_id)
    {
        $request->validate([
            'client_id' => 'required|exists:client,id',
            'date_visite' => 'required|date',
            'heure_visite' => 'required',
            'statut_visite' => 'required|string|max:50',
            'montant_visite' => 'required|numeric',
            'moyen_paiement' => 'required|string|max:50',
        ]);

        Visite::create([
            'bien_id' => $bien_id,
            'client_id' => $request->client_id,
            'date_visite' => $request->date_visite,
            'heure_visite' => $request->heure_visite,
            'statut_visite' => $request->statut_visite,
            'montant_visite' => $request->montant_visite,
            'moyen_paiement' => $request->moyen_paiement,
        ]);

        return redirect()->back()->with('success', 'Visite enregistrée avec succès pour ce bien.');
    }

    // 🔹 Recherche AJAX pour les visites
    public function rechercheAjax(Request $request)
    {
        $query = $request->input('query');
        $visites = Visite::where('statut_visite', 'LIKE', "%{$query}%")
            ->orWhere('date_visite', 'LIKE', "%{$query}%")
            ->get();

        return response()->json($visites);
    }
}
